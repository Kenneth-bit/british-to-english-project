module.exports = {
  'mr.': 'mr',
  'mrs.': 'mrs',
  'ms.': 'ms',
  'mx.': 'mx',
  'dr.': 'dr',
  'prof.': 'prof'
}
